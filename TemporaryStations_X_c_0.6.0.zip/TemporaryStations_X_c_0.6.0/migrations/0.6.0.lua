global.personal_train = {{}, {}}
_print("============================>>>")
_print({"notifications.clearing-personal-trains"})
